package uce.edu.GestionFlota;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GestionFlotaApplication {

	public static void main(String[] args) {
		SpringApplication.run(GestionFlotaApplication.class, args);
	}

}
